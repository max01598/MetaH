package jobshop.encodings;

import java.util.ArrayList;
import java.util.Arrays;

import jobshop.Encoding;
import jobshop.Instance;
import jobshop.Schedule;

public class ResourceOrder extends Encoding {
	/*Ici faire comme schedule sauf que la matrice 
	 *va contenir une representation par ordre de passage cf sujet
	 */
	public final Task[][] resources;

	public ResourceOrder(Instance pb) {
		super(pb);
		this.resources = new Task[pb.numMachines][pb.numJobs];
	}

	@Override
	public Schedule toSchedule() {
		ArrayList<Task> taskScheduled = new ArrayList<Task>();
		int[][] startTimes = new int[instance.numJobs][instance.numTasks];
		int machine_act = 0;
		while(taskScheduled.size()!= (this.instance.numTasks*this.instance.numJobs))
		{
			for (Task[] taskByMachine : this.resources) {
				for(int indexOrder=0; indexOrder<this.instance.numJobs;indexOrder++)
				{
					Task t_act = taskByMachine[indexOrder];
					int job = t_act.job;
					int taskNumber = t_act.task;
					//Cas : il est le premier dans l'ordre de la machine et du job
					if(indexOrder==0 && taskNumber==0 && !taskScheduled.contains(t_act))
					{
						//Alors on l'ajoute au task schedul� et son temps de depart est 0
						taskScheduled.add(t_act);
						startTimes[job][taskNumber] = 0;
					}
					else {
						//Cas ou la tache precedente du job est dans la liste et que c'est la premiere tack sur la machine 
						if(isTaskOnTheList(taskScheduled,job,taskNumber-1) && indexOrder == 0 && !taskScheduled.contains(t_act))
						{
							//Alors on l'ajoute au task schedul� et son temps de depart est celui de la tache .... + son temps de travail
							taskScheduled.add(t_act);
							int task_departByJob = startTimes[job][taskNumber-1] + instance.duration(job, taskNumber-1);
							int task_departByMachine = 0;
					        int task_duration = Math.max(task_departByJob,task_departByMachine);
					        startTimes[job][taskNumber] = task_duration;
						}
						else
						{
							//On recupere alors la tache precedente sur la machine
							Task previousTaskOnMachine = this.resources[machine_act][indexOrder-1];
							//Si elle est dans la liste ...
							if(isTaskOnTheList(taskScheduled, previousTaskOnMachine.job, previousTaskOnMachine.task) && !taskScheduled.contains(t_act))
							{
								//Alors on l'ajoute au task schedul� et son temps de depart est celui de la tache .... + son temps de travail
								taskScheduled.add(t_act);
								int task_departByJob = startTimes[job][taskNumber-1] + instance.duration(job, taskNumber-1);
								int task_departByMachine = startTimes[previousTaskOnMachine.job][previousTaskOnMachine.task] + instance.duration(previousTaskOnMachine.job, previousTaskOnMachine.task);
						        int task_duration = Math.max(task_departByJob,task_departByMachine);
						        startTimes[job][taskNumber] = task_duration;
							}
						}
					}
				}
				machine_act++;
			}
		}
        return new Schedule(instance, startTimes);
	}

	private Boolean isTaskOnTheList(ArrayList<Task> list,int task_job, int task_number)
	{
		for (Task task : list) {
			if(task.job==task_job && task.task==task_number)
			{
				return true;
			}
		}
		return false;
	}
	
	public String toString()
	{
		String s = "";
		int machine_index = 0;
		for (Task[] tasks : resources) {
			s += "Machine : "+ machine_index + " | ";
			for(int t=0; t<tasks.length;t++)
			{
				s += tasks[t].toString() + " | ";
			}
			s+= "\n";
			machine_index++;
		}
		return s;
	}
	
	public ResourceOrder fromSchedule(Schedule s)
    {
    	ResourceOrder r = new ResourceOrder(s.pb);
    	int nbJob = r.instance.numJobs;
    	int nbMachine = r.instance.numMachines;
    	for(int machine = 0; machine < nbMachine;machine++)
    	{
    		Task[] tasksSameMachine = new Task[nbJob];
    		for(int job=0;job<nbJob;job++)
    		{
    			tasksSameMachine[job] = new Task(job,r.instance.task_with_machine(job, machine));
    		}
    		//On trie le tableau
    		Task[] tasksSorted = SortByTimeStart(s,tasksSameMachine);
    		r.resources[machine] = tasksSorted;
    	}
    	return r;
    }

	private Task[] SortByTimeStart(Schedule s, Task[] taskOnTheMachine) {
		Task[] tasksSorted = new Task[s.pb.numJobs];
		for(int i = 0;i<taskOnTheMachine.length - 1;i++)
		{
			Task t_act = taskOnTheMachine[i];
			Task next_act = taskOnTheMachine[i+1];
			if(s.startTime(t_act.job, t_act.task) > s.startTime(next_act.job, next_act.task))
			{
				Task temp = t_act;
				taskOnTheMachine[i] = next_act;
				taskOnTheMachine[i+1] = temp;
			}
			
		}
		tasksSorted = taskOnTheMachine;
		return tasksSorted;
	}
	
}
